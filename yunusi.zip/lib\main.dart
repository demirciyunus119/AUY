import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:permission_handler/permission_handler.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Durum çubuğunu ve navigasyon tuşlarını gizle (Tam Ekran Modu)
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const YunusiApp());
}

class YunusiApp extends StatelessWidget {
  const YunusiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'yunusi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.deepPurple,
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  String? _filePath;
  String? _fileType;
  bool _showSettingsButton = false;
  VideoPlayerController? _videoController;
  bool _isVideoInitialized = false;
  String? _textContents;

  @override
  void initState() {
    super.initState();
    _loadSavedFile();
    _requestInitialPermissions();
  }

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }

  // İzinleri iste
  Future<void> _requestInitialPermissions() async {
    // Depolama izni
    if (await Permission.storage.request().isDenied) {
      // Android 13+ için özel izinler gerekebilir
      await Permission.photos.request();
      await Permission.videos.request();
    }
  }

  // Kayıtlı dosyayı yükle
  Future<void> _loadSavedFile() async {
    final prefs = await SharedPreferences.getInstance();
    final savedPath = prefs.getString('saved_file_path');
    final savedType = prefs.getString('saved_file_type');

    if (savedPath != null && await File(savedPath).exists()) {
      setState(() {
        _filePath = savedPath;
        _fileType = savedType;
      });

      if (savedType == 'video') {
        _initializeVideo(savedPath);
      } else if (savedType == 'text') {
        _readTextFile(savedPath);
      }
    }
  }

  // Video oynatıcıyı başlat
  Future<void> _initializeVideo(String path) async {
    _videoController?.dispose();
    _videoController = VideoPlayerController.file(File(path))
      ..initialize().then((_) {
        setState(() {
          _isVideoInitialized = true;
        });
        _videoController!.setLooping(true);
        _videoController!.play();
      });
  }

  // Metin dosyasını oku
  Future<void> _readTextFile(String path) async {
    try {
      final file = File(path);
      final contents = await file.readAsString();
      setState(() {
        _textContents = contents;
      });
    } catch (e) {
      setState(() {
        _textContents = "Metin dosyası okunurken hata oluştu: $e";
      });
    }
  }

  // Dosya seçiciyi aç ve dosyayı yerel depolamaya kopyala
  Future<void> _pickAndSaveFile() async {
    // İzinleri kontrol et
    await _requestInitialPermissions();

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'mkv', 'avi', 'txt', 'html'],
    );

    if (result != null && result.files.single.path != null) {
      final originalFile = File(result.files.single.path!);
      final extension = result.files.single.extension?.toLowerCase();

      // Dosya tipini belirle
      String type = 'image';
      if (['mp4', 'mkv', 'avi'].contains(extension)) {
        type = 'video';
      } else if (['txt', 'html'].contains(extension)) {
        type = 'text';
      }

      // Dosyayı uygulamanın kendi güvenli dizinine kopyala (Boot esnasında erişilebilirlik için)
      final appDir = await getApplicationDocumentsDirectory();
      final fileName = 'boot_display_file_${DateTime.now().millisecondsSinceEpoch}.$extension';
      final savedFile = await originalFile.copy('${appDir.path}/$fileName');

      // Eski dosyayı sil (varsa yer kaplamasın)
      if (_filePath != null) {
        try {
          final oldFile = File(_filePath!);
          if (await oldFile.exists()) {
            await oldFile.delete();
          }
        } catch (e) {
          // Hata yok sayılabilir
        }
      }

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('saved_file_path', savedFile.path);
      await prefs.setString('saved_file_type', type);

      setState(() {
        _filePath = savedFile.path;
        _fileType = type;
        _showSettingsButton = false;
      });

      if (type == 'video') {
        _initializeVideo(savedFile.path);
      } else if (type == 'text') {
        _readTextFile(savedFile.path);
      }
    }
  }

  // Seçilen dosyayı temizle
  Future<void> _clearSelectedFile() async {
    if (_filePath != null) {
      try {
        final file = File(_filePath!);
        if (await file.exists()) {
          await file.delete();
        }
      } catch (e) {
        // Hata
      }
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('saved_file_path');
    await prefs.remove('saved_file_type');

    _videoController?.dispose();
    _videoController = null;

    setState(() {
      _filePath = null;
      _fileType = null;
      _isVideoInitialized = false;
      _textContents = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        // Ekrana çift tıklandığında ayarlar butonunu göster/gizle
        onDoubleTap: () {
          setState(() {
            _showSettingsButton = !_showSettingsButton;
          });
        },
        child: Stack(
          children: [
            // İÇERİK GÖSTERİCİ (FİLE VIEWER)
            Positioned.fill(
              child: _buildDisplayContent(),
            ),

            // ÇİFT TIKLAMA YÖNLENDİRMESİ (Dosya Seçilmediyse veya Ayarlar Butonu Açıkken)
            if (_filePath == null)
              Positioned.fill(
                child: _buildWelcomeScreen(),
              ),

            // AYARLAR BUTONU VE ARAYÜZÜ
            if (_showSettingsButton && _filePath != null)
              Positioned(
                top: 40,
                right: 20,
                child: FloatingActionButton(
                  backgroundColor: Colors.deepPurple.withOpacity(0.8),
                  child: const Icon(Icons.settings, color: Colors.white),
                  onPressed: () => _showSettingsDialog(context),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // Seçilen dosyayı ekrana yerleştir
  Widget _buildDisplayContent() {
    if (_filePath == null) {
      return const SizedBox.shrink();
    }

    if (_fileType == 'image') {
      return Image.file(
        File(_filePath!),
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => _buildErrorWidget(error),
      );
    } else if (_fileType == 'video') {
      if (_videoController != null && _isVideoInitialized) {
        return FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _videoController!.value.size.width,
            height: _videoController!.value.size.height,
            child: VideoPlayer(_videoController!),
          ),
        );
      } else {
        return const Center(child: CircularProgressIndicator(color: Colors.deepPurple));
      }
    } else if (_fileType == 'text') {
      return SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Text(
            _textContents ?? 'Metin yükleniyor...',
            style: const TextStyle(
              fontSize: 18,
              color: Colors.white,
              height: 1.5,
              fontFamily: 'Courier',
            ),
          ),
        ),
      );
    }

    return const Center(
      child: Text('Desteklenmeyen dosya türü.', style: TextStyle(color: Colors.white)),
    );
  }

  Widget _buildErrorWidget(Object error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.redAccent),
            const SizedBox(height: 16),
            Text(
              'Dosya yüklenirken hata oluştu:\n$error',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.redAccent, fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }

  // Dosya seçilmemişken gösterilen Hoş Geldiniz Ekranı (Premium Tasarım)
  Widget _buildWelcomeScreen() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.black, Colors.deepPurple.shade900.withOpacity(0.5), Colors.black],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Logo veya İkon
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.deepPurple.withOpacity(0.2),
                  border: Border.all(color: Colors.deepPurple.shade300, width: 2),
                ),
                child: const Icon(
                  Icons.phone_android,
                  size: 80,
                  color: Colors.deepPurpleAccent,
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'yunusi',
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2.0,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Açılışta Otomatik Dosya Gösterici',
                style: TextStyle(fontSize: 16, color: Colors.grey),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 40),
              // Dosya Seçme Butonu
              ElevatedButton.icon(
                onPressed: _pickAndSaveFile,
                icon: const Icon(Icons.file_open_rounded, color: Colors.white),
                label: const Text(
                  'Gösterilecek Dosyayı Seçin',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 5,
                ),
              ),
              const SizedBox(height: 48),
              // Bilgilendirme Kartı
              Card(
                color: Colors.white.withOpacity(0.05),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: BorderSide(color: Colors.white.withOpacity(0.1)),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  value: 1.0, // dummy parameter to bypass lint or similar
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.info_outline, color: Colors.deepPurpleAccent),
                          SizedBox(width: 8),
                          Text(
                            'Nasıl Çalışır?',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _buildStepItem('1.', 'Gösterilmesini istediğiniz bir resim, video veya metin dosyası seçin.'),
                      _buildStepItem('2.', 'Uygulama bu dosyayı güvenli bir şekilde kaydeder.'),
                      _buildStepItem('3.', 'Telefonunuzu yeniden başlattığınızda, orijinal boot ekranının hemen ardından bu dosya tam ekran olarak otomatik açılır.'),
                      _buildStepItem('4.', 'Ayarlar menüsünü açmak veya dosyayı değiştirmek için ekrana çift tıklamanız yeterlidir.'),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStepItem(String number, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            number,
            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.deepPurpleAccent, fontSize: 15),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: Colors.white70, fontSize: 14, height: 1.3),
            ),
          ),
        ],
      ),
    );
  }

  // Ayarlar Pop-up İletişim Kutusu
  void _showSettingsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          backgroundColor: Colors.grey.shade900,
          title: const Row(
            children: [
              Icon(Icons.settings, color: Colors.deepPurpleAccent),
              SizedBox(width: 8),
              Text('yunusi Ayarları', style: TextStyle(color: Colors.white)),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Mevcut Dosya:',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white70),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    _filePath?.split('/').last ?? 'Seçili dosya yok',
                    style: const TextStyle(fontFamily: 'Courier', color: Colors.greenAccent),
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Önemli İzinler:',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white70),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Android 10+ cihazlarda uygulamanın açılışta doğrudan ekranı kaplaması için "Üstte Gösterim" (Draw over other apps) ve "Otomatik Başlatma" (Autostart) izinlerinin sistem ayarlarından manuel olarak verilmesi gerekebilir.',
                  style: TextStyle(fontSize: 13, color: Colors.white54),
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () {
                    openAppSettings();
                  },
                  icon: const Icon(Icons.settings_applications, color: Colors.white),
                  label: const Text('Uygulama İzinlerini Aç', style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.1),
                    minimumSize: const Size(double.infinity, 40),
                  ),
                ),
                const SizedBox(height: 20),
                const Divider(color: Colors.white24),
                const SizedBox(height: 10),
                // İşlemler
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _pickAndSaveFile();
                  },
                  icon: const Icon(Icons.file_copy, color: Colors.white),
                  label: const Text('Dosyayı Değiştir', style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    minimumSize: const Size(double.infinity, 45),
                  ),
                ),
                const SizedBox(height: 8),
                TextButton.icon(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _clearSelectedFile();
                  },
                  icon: const Icon(Icons.delete_forever, color: Colors.redAccent),
                  label: const Text('Dosyayı Temizle (Seçimi Kaldır)', style: TextStyle(color: Colors.redAccent)),
                  style: TextButton.styleFrom(
                    minimumSize: const Size(double.infinity, 45),
                  ),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Kapat', style: TextStyle(color: Colors.deepPurpleAccent)),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
