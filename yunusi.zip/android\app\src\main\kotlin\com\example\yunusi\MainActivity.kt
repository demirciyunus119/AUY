package com.example.yunusi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
